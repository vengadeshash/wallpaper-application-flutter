import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:Wallpaper/widget.dart';
import 'package:http/http.dart' as http;
import 'package:Wallpaper/models/Wallpapermodel.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<WallpaperModel> wallpaper = new List();

  String apikey = "563492ad6f9170000100000133e1361b6bb045af8f084d2bc5d88bad";
  getWallpaper() async {
    var response = await http.get(
        "https://api.pexels.com/v1/curated?per_page=1",
        headers: {"Authorization": apikey});
    print(response.body.toString());
    Map<String, dynamic> jsonData = jsonDecode(response.body);
    jsonData["photos"].forEach((element) {
      // print(element);
      WallpaperModel wallpaper = new WallpaperModel();
      WallpaperModel = jsonData[""]
    });
  }

  @override
  void initState() {
    getWallpaper();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: co(),
        elevation: 0,
      ),
      body: Container(
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                  color: Color(0xfff5f8fd),
                  borderRadius: BorderRadius.circular(16)),
              padding: EdgeInsets.symmetric(horizontal: 24),
              margin: EdgeInsets.symmetric(horizontal: 24),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      decoration: InputDecoration(
                          hintText: 'Search Wallpaper',
                          border: InputBorder.none),
                    ),
                  ),
                  Icon(Icons.search)
                ],
              ),
            ),
            SizedBox(height: 16),
            Container(
              height: 80,
            )
          ],
        ),
      ),
    );
  }
}

//563492ad6f9170000100000133e1361b6bb045af8f084d2bc5d88bad
