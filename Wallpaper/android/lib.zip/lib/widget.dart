import 'package:flutter/material.dart';

Widget co() {
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [

      Text('Wallpaper',style: TextStyle(color: Colors.black26),),
      Text(''),
      Text(
        '4K',
        style: TextStyle(color: Colors.blueAccent),
      )
    ],
  );
}
